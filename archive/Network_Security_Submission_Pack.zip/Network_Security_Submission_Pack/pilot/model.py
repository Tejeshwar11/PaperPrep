"""Finite-state pilot, NOT a model of any vendor implementation.

Run: python3 model.py > results.json
Python standard library only. Exhaustive reachability over the finite abstraction.
"""
from collections import deque
from dataclasses import dataclass, replace, asdict
import json


@dataclass(frozen=True)
class State:
    requested: bool = False
    acknowledged: bool = False
    primary_alive: bool = True
    backup_active: bool = False
    backup_deny: bool = False
    backup_connection: bool = True
    delete_received: bool = False
    old_snapshot_pending: bool = True


MODES = ('local_ack', 'policy_ack', 'policy_and_delete_ack',
         'policy_and_delete_ack_with_tombstone')


def successors(s, mode):
    # The primary's atomic block removes its own connection and enqueues
    # one policy update and one deletion. Its local state is derived from
    # requested; in-flight messages remain deliverable after its crash.
    if s.primary_alive and not s.requested:
        yield 'request_block_on_primary', replace(s, requested=True)
    if s.requested and not s.backup_deny:
        yield 'deliver_deny_policy', replace(s, backup_deny=True)
    if s.requested and not s.delete_received:
        yield 'deliver_connection_deletion', replace(
            s, delete_received=True, backup_connection=False)
    if s.old_snapshot_pending:
        protected = mode == MODES[3] and s.delete_received
        yield ('reject_stale_connection_snapshot' if protected
               else 'install_old_connection_snapshot'), replace(
                   s, old_snapshot_pending=False,
                   backup_connection=s.backup_connection if protected else True)
    ready = (mode == MODES[0] or
             (mode == MODES[1] and s.backup_deny) or
             (mode in MODES[2:] and s.backup_deny and s.delete_received))
    if s.primary_alive and s.requested and not s.acknowledged and ready:
        yield 'acknowledge_block_completed', replace(s, acknowledged=True)
    if s.primary_alive and s.requested:
        yield 'primary_crashes', replace(s, primary_alive=False)
    if not s.primary_alive and not s.backup_active:
        yield 'backup_takes_over', replace(s, backup_active=True)


def permits_target(s):
    # Explicit established-session precedence. Not universal firewall behavior.
    # Before takeover only a live primary forwards. New connections are
    # represented by the policy decision, without modelling a TCP handshake.
    if s.backup_active:
        return s.backup_connection or not s.backup_deny
    return s.primary_alive and not s.requested


def explore(mode):
    initial = State()
    queue = deque([initial])
    paths = {initial: []}
    violations = []
    transitions = 0
    ack_states = 0
    protected_takeover_states = 0
    while queue:
        s = queue.popleft()
        if s.acknowledged:
            ack_states += 1
        if s.acknowledged and s.backup_active and not permits_target(s):
            protected_takeover_states += 1
        if s.acknowledged and permits_target(s):
            violations.append(s)
        for event, nxt in successors(s, mode):
            transitions += 1
            if nxt not in paths:
                paths[nxt] = paths[s] + [event]
                queue.append(nxt)
    witness = violations[0] if violations else None
    return {
        'mode': mode,
        'reachable_states': len(paths),
        'transitions': transitions,
        'violating_states': len(violations),
        'acknowledged_states': ack_states,
        'acknowledged_safe_takeover_states': protected_takeover_states,
        'shortest_counterexample': paths[witness] + ['target_packet_is_allowed']
            if witness else None,
        'counterexample_state': asdict(witness) if witness else None,
    }


def main():
    results = [explore(mode) for mode in MODES]
    # Sanity checks: known-unsafe controls expose witnesses, and the protected
    # variant can acknowledge and take over, avoiding an always-deny/vacuous test.
    assert all(r['violating_states'] > 0 for r in results[:3])
    assert results[3]['violating_states'] == 0
    assert all(r['acknowledged_states'] > 0 for r in results)
    assert all(r['acknowledged_safe_takeover_states'] > 0 for r in results)
    print(json.dumps({
        'status': 'pilot abstraction; not publication-grade validation',
        'bounds': '2 nodes, 1 target flow, 1 block, 1 crash, 1 takeover, '
                  '1 policy delivery, 1 deletion delivery, 1 old snapshot',
        'property': 'acknowledged implies no subsequent target admission; '
                    'no reauthorization is modelled',
        'results': results,
    }, indent=2))


if __name__ == '__main__':
    main()
